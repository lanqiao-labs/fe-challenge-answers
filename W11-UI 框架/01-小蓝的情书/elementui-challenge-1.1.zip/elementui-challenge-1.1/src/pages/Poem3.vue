<template>
    <el-container>
        <el-header height="150px">
            <h3>爱的哲学（中英对照全文赏析）</h3>
            <p>作者：雪莱</p>
            <p>翻译：查良铮</p>
        </el-header>
        <el-main>
            <p>泉水总是向河水汇流，</p>
            <p>河水又汇入海中，</p>
            <p>天宇的轻风永远融有</p>
            <p>一种甜蜜的感情；</p>
            <p>世上哪有什么孤零零？</p>
            <p>万物由于自然律</p>
            <p>都必融汇于一种精神。</p>
            <p>何以你我却独异？</p>
            <p>The fountains mingle with the river</p>
            <p>And the rivers with the ocean,</p>
            <p>The winds of heaven mix for ever</p>
            <p>With a sweet emotion;</p>
            <p>Nothing in the world is single;</p>
            <p>All things by a law divine</p>
            <p>In one another's being mingle—</p>
            <p>Why not I with thine?</p>
        </el-main>
    </el-container>
</template>
<style>
    h3 {
        text-align: center;
    }
</style>