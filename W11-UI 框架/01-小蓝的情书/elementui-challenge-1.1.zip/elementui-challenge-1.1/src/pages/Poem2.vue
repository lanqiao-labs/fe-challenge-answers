<template>
    <el-container>
        <el-header height="100px">
            <h3>致橡树</h3>
            <p>作者：舒婷</p>
        </el-header>
        <el-main>
            <p>我如果爱你——绝不像攀援的凌霄花，</p>
            <p>借你的高枝炫耀自己；</p>
            <p>我如果爱你——绝不学痴情的鸟儿，</p>
            <p>为绿荫重复单调的歌曲；</p>
            <p>也不止像泉源，</p>
            <p>常年送来清凉的慰藉；</p>
            <p>也不止像险峰，</p>
            <p>增加你的高度，</p>
            <p>衬托你的威仪。</p>
        </el-main>
    </el-container>
</template>
<style>
    h3 {
        text-align: center;
    }
</style>