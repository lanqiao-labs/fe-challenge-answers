<template>
    <el-container>
        <el-header height="150px">
            <h3>飞鸟集（中英对照全文赏析）</h3>
            <p>作者：泰戈尔</p>
            <p>翻译：郑振铎</p>
        </el-header>
        <el-main>
            <p>世界对着它的爱人，把它浩翰的面具揭下了。</p>
            <p>它变小了，小如一首歌，小如一回永恒的接吻。</p>
            <p>The world puts off its mask of vastness to its lover.</p>
            <p>It becomes small as one song, as one kiss of the eternal.</p>
        </el-main>
    </el-container>
</template>
<style>
    h3 {
        text-align: center;
    }
</style>