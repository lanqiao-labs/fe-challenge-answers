<template>
    <el-container>
        <el-header height="250px">
            <h2>Welcome to Here!</h2>
            <p><img src="../assets/cat.png" alt="logo" width="300px" height="250px"></p>
        </el-header>
        <el-main>
            <p><i class="el-icon-phone"></i>联系电话：1234567</p>
            <p><i class="el-icon-message"></i>邮箱地址：123@gmail.com</p>
            <p><el-link type="info" icon="el-icon-lollipop">关于我们团队介绍</el-link></p>
        </el-main>
    </el-container>
</template>
<style>
h2,p {
    text-align: center;
}
.el-main {
    background: #fff;
}
</style>