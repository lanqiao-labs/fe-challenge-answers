<template>
  <div>
    <el-container>
      <el-header>
        <el-radio-group v-model="current">
          <el-radio-button
            v-for="view of views"
            :label="view"
            :key="view"
            @click="`current=${view}`"
          />
        </el-radio-group>
      </el-header>
      <el-main>
        <div :is="current">...</div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import Home from "./pages/Home";
import Poem1 from "./pages/Poem1";
import Poem2 from "./pages/Poem2";
import Poem3 from "./pages/Poem3";

const components = {
  Home,
  Poem1,
  Poem2,
  Poem3
};
export default {
  data() {
    const views = Object.keys(components);
    return {
      current: views[0],
      views
    };
  },
  components: {
    ...components
  }
};
</script>
<style>

</style>