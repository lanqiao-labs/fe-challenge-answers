<template>
    <div>
    <el-slider v-model="size" style="width: 100%"/>
    <el-space :size="size" wrap>
        <!--第一张卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                生日快乐呀～～
            </div>
            <p class="footer">From 小白</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
        <!--第二张卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                小蓝，生日快乐！！
            </div>
            <p class="footer">From 小红</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
        <!--第三章卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                又老了一岁，希望你越来越好。
            </div>
            <p class="footer">From 小绿</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
        <!--第四张卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                兄弟，生日快乐！
            </div>
            <p class="footer">From 小黄</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
        <!--第五张卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                成长快乐！
            </div>
            <p class="footer">From 小青</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
        <!--第六张卡片-->
        <el-card class="box-card">
            <template #header>
                <div>
                    <span>To 小蓝：</span>
                </div>
            </template>
            <div class="text">
                啦啦啦！送祝福来了～～
            </div>
            <p class="footer">From 小彩</p>
            <p class="date">2021 年 11 月 7 日</p>
        </el-card>
    </el-space>
    </div>
</template>
<script>
export default {
    data() {
        return {
            size: 50,
        }
    }
}
</script>
<style>
 .box-card {
    width: 300px;
  }
  .text {
    margin-bottom: 18px;
  }
  .footer {
    font-size: 13px;
    margin-left: 70%;
  }
  .date {
    font-size: 13px;
    margin-left: 55%;
  }
</style>