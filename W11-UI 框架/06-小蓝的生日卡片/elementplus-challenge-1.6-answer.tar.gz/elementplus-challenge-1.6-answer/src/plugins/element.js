import ElementPlus from 'element-plus'
import 'element-plus/lib/theme-chalk/index.css'

export default (app) => {
  app.use(ElementPlus)
}
