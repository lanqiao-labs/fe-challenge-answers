<template>
  <div id="app">
    <Space />
  </div>
</template>

<script>
import Space from './views/Space.vue'

export default {
  name: 'App',
  components: {
    Space
  }
}
</script>