<template>
<div class="login">
    <div class="container">
        <account-login 
        :rule-form="ruleForm" 
        :rules="rules"
        @submit="submit"
        @errHandle="errHandle">
        </account-login>
    </div>
</div>
</template>

<script>
export default {
    name: "Login",
    components: {},
    props: {},
    data() {
        return {
            ruleForm: {
                username: '',
                password: ''
            },
            rules: {
                username: [
                    {
                        required: true,
                        message: '用户名不能为空',
                        trigger: 'blur'
                    },
                    {
                        min: 2,
                        max: 6,
                        message: '用户名在 2～6 个字符之间',
                        trigger: 'blur'
                    }
                ],
                password: [
                    {
                        required: true,
                        message: '密码不能为空',
                        trigger: 'blur'
                    },
                    {
                        min: 6,
                        max: 12,
                        message: '密码在 6～12 个字符之间',
                        trigger: 'blur'
                    }
                ]   
            }
        }
    },
    methods: {
        submit() {
            this.$message.success('提交成功')
        },
        errHandle() {
            this.$message.error('表单填写有误')
        }
    },
    mounted() {},
}
</script>

<style>
.login {
    margin-top: 30px;
    margin-left: 30px;
}
.container {
    width: 350px;
}
</style>