<template>
<div>
   <el-container>
        <el-header height="150px">
            <h3>爱的哲学（中英对照全文赏析）</h3>
            <p>作者：雪莱</p>
            <p>翻译：查良铮</p>
        </el-header>
        <el-main>
            <p>泉水总是向河水汇流，</p>
            <p>河水又汇入海中，</p>
            <p>天宇的轻风永远融有</p>
            <p>一种甜蜜的感情；</p>
            <p>世上哪有什么孤零零？</p>
            <p>万物由于自然律</p>
            <p>都必融汇于一种精神。</p>
            <p>何以你我却独异？</p>
            <p>The fountains mingle with the river</p>
            <p>And the rivers with the ocean,</p>
            <p>The winds of heaven mix for ever</p>
            <p>With a sweet emotion;</p>
            <p>Nothing in the world is single;</p>
            <p>All things by a law divine</p>
            <p>In one another's being mingle—</p>
            <p>Why not I with thine?</p>
        </el-main>
        <el-footer>
            <p>雪莱（1792年8月4日—1822年7月8日），英国文学史上最有才华的抒情诗人之一，更被誉为诗人中的诗人。</p>
            <p>其一生见识广泛，不仅是柏拉图主义者，更是个伟大的理想主义者。</p> 
            <p>创作的诗歌节奏明快，积极向上。代表作品有长诗《解放了的普罗米修斯》和《倩契》，以及不朽的名作《西风颂》。</p>
            <p>马克思称他是“社会主义的急先锋”，恩格斯赞扬他为“天才的预言家”。鲁迅先生曾在他的《摩罗诗力说》中以“时既艰危，性复狷介”八个字概括了诗人的时代背景和性格特征。</p>
            <p>雪莱短暂的一生也正像他的诗歌展现的那样，虽然屡遭挫折，身处逆境，却仍能正直刚强，勇敢前行。</p>
        </el-footer>
    </el-container>
</div>
</template>
<script>
export default {
    name: "BackTopOne",
    components: {},
    props: {},
    data() {
        return {}
    },
    methods: {},
    mounted() {},
}
</script>