<template>
    <div class="pages-content-scroll">
        <el-backtop target=".pages-content-scroll"></el-backtop>
        <!--插槽会填入所有的页面-->
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: "BackTop",
    components: {},
    props: {},
    data() {
        return {}
    },
    methods: {},
    mounted() {},
}
</script>
<style lang="scss" scoped>
.pages-content-scroll {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    overflow-x: hidden;
}
</style>