<template>
  <div>
    <back-top>
      <!--router-view 去承载我们的路由-->
      <router-view/>
    </back-top>
  </div>
</template>
<style lang="scss">

</style>
