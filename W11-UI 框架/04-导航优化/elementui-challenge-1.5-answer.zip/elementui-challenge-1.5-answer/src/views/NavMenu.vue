<template>
  <el-menu mode="horizontal" 
  :default-active="activeIndex" 
  active-text-color="#409eff">
    <el-menu-item index="1">
      <b class="title">蓝桥水果市场</b>
    </el-menu-item>
    <el-menu-item index="2">
        <i class="el-icon-s-home"></i>
        主页
    </el-menu-item>
    <el-submenu index="3">
      <template slot="title">
        <i class="el-icon-cherry"></i>
        <span>水果分类</span>
      </template>
      <el-menu-item-group>
        <el-menu-item index="3-1">橙柚柑橘</el-menu-item>
        <el-menu-item index="3-2">苹果梨蕉</el-menu-item>
        <el-menu-item index="3-3">热带水果</el-menu-item>
        <el-menu-item index="3-4">奇异果/枣李</el-menu-item>
        <el-menu-item index="3-5">葡萄/瓜果</el-menu-item>
        <el-menu-item index="3-6">车厘子/蓝莓</el-menu-item>
      </el-menu-item-group>
    </el-submenu>
    <el-menu-item index="4">
      <i class="el-icon-star-on"></i>
      个人收藏
    </el-menu-item>
    <el-menu-item index="5">
      <i class="el-icon-user-solid"></i>
      个人设置
    </el-menu-item>
    <el-menu-item index="6">
      <i class="el-icon-more"></i>
      更多
    </el-menu-item>
    <el-menu-item class="login">
      <el-button icon="el-icon-upload"  
      size="mini"
      type="primary"
      style="margin-left: 50px">
      登录
      </el-button>
    </el-menu-item>
    <el-menu-item>
      <el-button icon="el-icon-edit" 
      size="mini">
      注册
      </el-button>
    </el-menu-item>
  </el-menu>
</template>

<script>
export default {
  data() {
      return {
        activeIndex: '2'
      };
    },
}
</script>

<style>
.title {
  color: #409eff;
  font-size: 20px;
}
</style>