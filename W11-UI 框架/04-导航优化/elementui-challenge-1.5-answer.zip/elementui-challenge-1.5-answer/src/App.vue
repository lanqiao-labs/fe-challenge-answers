<template>
  <div id="app">
    <NavMenu />
  </div>
</template>

<script>
import NavMenu from './views/NavMenu.vue'

export default {
  name: 'App',
  components: {
    NavMenu
  }
}
</script>
